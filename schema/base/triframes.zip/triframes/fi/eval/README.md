http://data.dws.informatik.uni-mannheim.de/dustalov/frame-induction/korhonen2003.poly.txt


```
groovy -classpath watset.jar ./fi/eval/verbs_nmpu.groovy -pt arguments.txt korhonen2003.poly.txt
```
